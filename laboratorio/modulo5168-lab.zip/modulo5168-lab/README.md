# Laboratorio del módulo 5168

Proyecto de ejemplo para las prácticas de las cuatro unidades. Se sube entero a Gitea
(repositorio `modulo5168-lab`) y Jenkins lo ejecuta con `lab/Jenkinsfile`.

```
lab/
├── Jenkinsfile            Pipeline completo (UT1 a UT4)
├── Jenkinsfile.warmup     Pipeline reducido: build, comprobación y push
├── app/                   Aplicación Node.js (Dockerfile, Dockerfile.singlestage, server.js, package.json)
├── k8s/                   Deployment, Service, Redis y render.sh
├── ansible/               Playbook, variables por entorno y plantilla del ConfigMap
└── scripts/               Validación de la instalación y pruebas
```

Valores del laboratorio: registry `localhost:5000`, aplicación en `http://192.168.49.2:30080`
(variable `APP_URL`), credenciales de Jenkins `registry-credentials` y `kubeconfig-aula`.
La guía de instalación explica cómo montar el entorno.
