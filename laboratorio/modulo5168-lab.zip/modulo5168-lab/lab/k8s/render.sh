#!/bin/bash
# Sustituye los marcadores de deployment.yaml y escribe el resultado por la salida estándar.
# Uso:  lab/k8s/render.sh IMAGEN [REPLICAS]
# Ej.:  lab/k8s/render.sh localhost:5000/modulo5168-app:1.2.0 2 | kubectl apply -f -
set -euo pipefail
IMAGEN="${1:?Uso: render.sh IMAGEN [REPLICAS]}"
REPLICAS="${2:-1}"
DIR="$(cd "$(dirname "$0")" && pwd)"
sed -e "s#REGISTRY/modulo5168-app:IMAGE_TAG#${IMAGEN}#g" \
    -e "s#replicas: REPLICAS#replicas: ${REPLICAS}#" \
    "$DIR/deployment.yaml"
