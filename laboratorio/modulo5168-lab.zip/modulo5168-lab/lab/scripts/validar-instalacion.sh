#!/bin/bash
# UT3 (criterio b): valida, justo después de instalar, que la app y su dependencia están bien.
# Dirección de la app: variable APP_URL (por defecto, el NodePort de Minikube).
APP_URL="${APP_URL:-http://192.168.49.2:30080}"

echo "Comprobando que la app responde en ${APP_URL}..."
curl -sf --retry 5 --retry-delay 2 --retry-connrefused "${APP_URL}/health" > /dev/null \
  || { echo "FALLO: la app no responde"; exit 1; }

echo "Comprobando conexión con Redis..."
RESPUESTA=$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/counter")
echo "$RESPUESTA" | grep -q visitas \
  || { echo "FALLO: no se puede conectar a Redis"; exit 1; }

echo "Instalación validada correctamente."
