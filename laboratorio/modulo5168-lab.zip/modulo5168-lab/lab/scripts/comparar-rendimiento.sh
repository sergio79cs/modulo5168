#!/bin/bash
# UT4 (criterio c): decide si una versión es apta comparando su prueba de carga con la anterior.
# Uso: comparar-rendimiento.sh RESULTADO_ACTUAL RESULTADO_ANTERIOR [UMBRAL_PORCENTAJE]
# Falla (exit 1) si el tiempo por petición empeora más del umbral (por defecto, 20 %).
ACTUAL_FILE="${1:?Uso: comparar-rendimiento.sh ACTUAL ANTERIOR [UMBRAL]}"
ANTERIOR_FILE="${2:?Uso: comparar-rendimiento.sh ACTUAL ANTERIOR [UMBRAL]}"
UMBRAL="${3:-20}"

extraer() { grep 'Time per request' "$1" | head -1 | awk '{print $4}'; }

ACTUAL=$(extraer "$ACTUAL_FILE")
ANTERIOR=$(extraer "$ANTERIOR_FILE")
if [ -z "$ACTUAL" ] || [ -z "$ANTERIOR" ]; then
  echo "FALLO: no se encuentra 'Time per request' en los resultados"
  exit 1
fi

echo "Tiempo por petición: actual ${ACTUAL} ms, anterior ${ANTERIOR} ms (umbral +${UMBRAL} %)"
if awk -v a="$ACTUAL" -v b="$ANTERIOR" -v u="$UMBRAL" 'BEGIN { exit !(a > b * (1 + u / 100)) }'; then
  echo "FALLO: rendimiento degradado más de un ${UMBRAL} % respecto a la versión anterior"
  exit 1
fi
echo "OK: el rendimiento se mantiene dentro del umbral"
