#!/bin/bash
# UT1 (RA1.e) y UT4 (RA4.a): pruebas funcionales básicas de la API.
# Dirección de la app: variable APP_URL.
#   - Contenedor de prueba en tu equipo:  APP_URL=http://localhost:3001
#   - Aplicación desplegada en Minikube:  APP_URL=http://$(minikube ip):30080
APP_URL="${APP_URL:-${URL:-http://192.168.49.2:30080}}"   # también acepta URL, como el script de la UT01
FALLOS=0

comprobar() {
  local nombre="$1" esperado="$2" real="$3"
  if echo "$real" | grep -q "$esperado"; then
    echo "PASS: $nombre"
  else
    echo "FAIL: $nombre (esperaba '$esperado', recibido '$real')"
    FALLOS=$((FALLOS + 1))
  fi
}

comprobar "GET / saluda"      "Hola"           "$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/")"
comprobar "GET /health"       '"status":"ok"'  "$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/health")"
comprobar "GET /version"      '"version"'      "$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/version")"

if [ "$FALLOS" -gt 0 ]; then
  echo "Pruebas funcionales: ${FALLOS} fallo(s)"
  exit 1
fi
echo "Pruebas funcionales: todas correctas"
