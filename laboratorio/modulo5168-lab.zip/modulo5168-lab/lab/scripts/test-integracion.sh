#!/bin/bash
# UT3 (criterio c): prueba funcional de la integración app + Redis.
APP_URL="${APP_URL:-http://192.168.49.2:30080}"

V1=$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/counter" | grep -o '[0-9]*')
V2=$(curl -s --retry 3 --retry-delay 2 "${APP_URL}/counter" | grep -o '[0-9]*')

if [ -n "$V1" ] && [ -n "$V2" ] && [ "$V2" -eq $((V1 + 1)) ]; then
  echo "PASS: el contador se incrementa correctamente vía Redis ($V1 -> $V2)"
else
  echo "FAIL: la integración con Redis no funciona como se espera"
  exit 1
fi
