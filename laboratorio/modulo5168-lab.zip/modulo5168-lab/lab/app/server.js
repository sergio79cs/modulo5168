// App de ejemplo para las prácticas del módulo 5168
// Endpoints: /  /health  /version  /counter (UT3, usa Redis)  /metrics (UT4)
const express = require("express");
const { createClient } = require("redis");

const app = express();
const PORT = process.env.PORT || 3000;
const VERSION = process.env.APP_VERSION || "dev";
const REDIS_URL = process.env.REDIS_URL || "redis://redis:6379";

// Cliente de Redis. Si Redis no está disponible, la app arranca igualmente:
// /health responde y /counter devuelve 503 hasta que haya conexión.
const client = createClient({ url: REDIS_URL });
client.on("error", (err) => console.error("Redis:", err.message));
client.connect().catch((err) => console.error("Redis no disponible:", err.message));

app.get("/", (req, res) => {
  res.send(`Hola desde el módulo 5168 · versión ${VERSION}`);
});

app.get("/health", (req, res) => {
  res.status(200).json({ status: "ok", version: VERSION, uptime: process.uptime() });
});

app.get("/version", (req, res) => {
  res.status(200).json({ version: VERSION });
});

// UT3: artefacto de integración con Redis
app.get("/counter", async (req, res) => {
  if (!client.isReady) {
    return res.status(503).json({ error: "Redis no disponible" });
  }
  try {
    const visitas = await client.incr("visitas");
    res.json({ visitas });
  } catch (err) {
    res.status(503).json({ error: err.message });
  }
});

// UT4: métricas en formato de texto (estilo Prometheus)
app.get("/metrics", (req, res) => {
  res.set("Content-Type", "text/plain");
  res.send(`app_version{version="${VERSION}"} 1\napp_uptime_seconds ${process.uptime()}\n`);
});

const server = app.listen(PORT, () => {
  console.log(`App escuchando en el puerto ${PORT} (versión ${VERSION})`);
});

// Parada ordenada: Kubernetes envía SIGTERM al sustituir un pod
process.on("SIGTERM", () => {
  server.close(() => process.exit(0));
});
